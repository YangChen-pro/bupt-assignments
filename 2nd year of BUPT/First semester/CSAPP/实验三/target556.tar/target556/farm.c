/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_329()
{
    return 3347660934U;
}

unsigned addval_350(unsigned x)
{
    return x + 1084473944U;
}

unsigned getval_123()
{
    return 3347662937U;
}

unsigned addval_353(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_267(unsigned x)
{
    return x + 3348711428U;
}

void setval_439(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_464(unsigned x)
{
    return x + 1723908952U;
}

unsigned addval_415(unsigned x)
{
    return x + 3135095576U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_299()
{
    return 3255410405U;
}

void setval_286(unsigned *p)
{
    *p = 3247492745U;
}

unsigned getval_409()
{
    return 3767093267U;
}

unsigned addval_304(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_220()
{
    return 3531918985U;
}

void setval_407(unsigned *p)
{
    *p = 3374895497U;
}

unsigned getval_385()
{
    return 2497743176U;
}

unsigned addval_413(unsigned x)
{
    return x + 3523793289U;
}

void setval_184(unsigned *p)
{
    *p = 3534016137U;
}

unsigned addval_328(unsigned x)
{
    return x + 3286270280U;
}

void setval_493(unsigned *p)
{
    *p = 3373846153U;
}

unsigned addval_332(unsigned x)
{
    return x + 3229926017U;
}

void setval_157(unsigned *p)
{
    *p = 2425409993U;
}

void setval_131(unsigned *p)
{
    *p = 3375940233U;
}

unsigned addval_259(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_323(unsigned x)
{
    return x + 3515420244U;
}

unsigned getval_140()
{
    return 3381972617U;
}

unsigned addval_471(unsigned x)
{
    return x + 3229926041U;
}

void setval_425(unsigned *p)
{
    *p = 3234123401U;
}

unsigned getval_183()
{
    return 4005806793U;
}

unsigned addval_285(unsigned x)
{
    return x + 3229929737U;
}

void setval_303(unsigned *p)
{
    *p = 3223900553U;
}

void setval_159(unsigned *p)
{
    *p = 3252717896U;
}

void setval_400(unsigned *p)
{
    *p = 331596425U;
}

unsigned addval_284(unsigned x)
{
    return x + 3247489673U;
}

unsigned addval_379(unsigned x)
{
    return x + 3286239560U;
}

void setval_247(unsigned *p)
{
    *p = 3527983753U;
}

unsigned addval_279(unsigned x)
{
    return x + 3676885385U;
}

void setval_119(unsigned *p)
{
    *p = 3525365389U;
}

void setval_394(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_127(unsigned x)
{
    return x + 3268512057U;
}

unsigned addval_365(unsigned x)
{
    return x + 3281047177U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
