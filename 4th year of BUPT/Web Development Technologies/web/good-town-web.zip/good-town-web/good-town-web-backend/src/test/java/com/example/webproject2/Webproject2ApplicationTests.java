package com.example.webproject2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Webproject2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
