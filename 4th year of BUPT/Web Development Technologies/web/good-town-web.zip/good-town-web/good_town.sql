-- MySQL dump 10.13  Distrib 9.0.1, for macos14.7 (arm64)
--
-- Host: localhost    Database: good_town
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assistance`
--

DROP TABLE IF EXISTS `assistance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assistance` (
  `assistance_id` int NOT NULL AUTO_INCREMENT,
  `publicity_id` int NOT NULL,
  `user_id` int NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(2550) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(2550) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint NOT NULL,
  PRIMARY KEY (`assistance_id`),
  KEY `publicity_id` (`publicity_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `assistance_ibfk_1` FOREIGN KEY (`publicity_id`) REFERENCES `publicity` (`publicity_id`),
  CONSTRAINT `assistance_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `assistance_chk_1` CHECK ((`status` in (0,1,2,3)))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assistance`
--

LOCK TABLES `assistance` WRITE;
/*!40000 ALTER TABLE `assistance` DISABLE KEYS */;
INSERT INTO `assistance` VALUES (2,12,4,'愿意协助松柏镇红色旅游宣传工作。','','','2023-01-20 01:30:00','2023-01-20 01:30:00',1),(3,13,5,'帮助宣传碧水镇的划船旅游活动。','','','2023-03-01 05:00:00','2023-03-01 05:00:00',2),(4,14,6,'协助星月镇的夜市活动推广宣传。','','','2023-04-01 10:00:00','2023-04-01 10:00:00',0),(5,15,7,'愿意支持金桂镇地方特产宣传工作。','','','2023-05-15 03:00:00','2023-05-15 03:00:00',1),(6,16,8,'帮助宣传银杏镇的生态旅游资源。','','','2023-06-10 04:00:00','2023-06-10 04:00:00',2),(7,17,9,'协助推广红枫镇的登山旅游项目。','','','2023-07-15 01:30:00','2023-07-15 01:30:00',0),(8,18,10,'愿意支持百合镇花卉观赏活动宣传。','','','2023-08-01 08:00:00','2023-08-01 08:00:00',1),(9,19,1,'帮助宣传荷花镇的荷花节文化活动。','','','2023-09-10 06:30:00','2023-09-10 06:30:00',2),(10,20,2,'协助绿柳镇古街文化的推广宣传。','','','2023-10-01 02:00:00','2023-10-01 02:00:00',0),(11,21,3,'愿意支持绿水镇民俗文化展示活动。','','','2023-11-01 03:00:00','2023-11-01 03:00:00',1),(12,22,4,'帮助宣传金川镇历史遗迹活动。','','','2023-12-01 07:00:00','2023-12-01 07:00:00',2),(13,23,5,'协助推广天河镇的采摘活动。','','','2024-01-10 02:00:00','2024-01-10 02:00:00',0),(14,24,6,'愿意支持松柏镇冬季雪景宣传工作。','','','2024-02-01 03:00:00','2024-02-01 03:00:00',1),(15,25,7,'帮助宣传金桂镇的桂花糕美食。','','','2024-03-01 06:30:00','2024-03-01 06:30:00',2),(16,26,8,'协助阳光镇的摄影旅游推广宣传。','','','2024-04-01 02:00:00','2024-04-01 02:00:00',0),(17,27,9,'愿意支持红山镇火锅文化推广活动。','','','2024-05-01 07:00:00','2024-05-01 07:00:00',1),(18,28,10,'帮助宣传青山镇的春季花卉展览活动。','','','2024-06-01 01:00:00','2024-06-01 01:00:00',2),(20,30,2,'愿意支持银泉镇生态农场宣传工作。','','','2024-08-01 02:00:00','2024-08-01 02:00:00',1),(21,31,3,'帮助宣传白云镇传统舞蹈活动。','','','2024-09-01 06:30:00','2024-09-01 06:30:00',2),(22,32,4,'协助东风镇夏季灯光秀宣传推广。','','','2024-10-01 12:00:00','2024-10-01 12:00:00',0),(23,33,5,'愿意支持春柳镇绿道骑行项目宣传。','','','2024-11-01 01:00:00','2024-11-01 01:00:00',1),(24,34,6,'帮助宣传星月镇的星空音乐节活动。','','','2024-12-01 10:00:00','2024-12-01 10:00:00',2),(25,35,7,'协助红枫镇健身步道推广宣传。','','','2023-02-01 02:00:00','2023-02-01 02:00:00',0),(26,36,8,'愿意支持绿柳镇的古街夜景宣传活动。','','','2023-03-01 03:00:00','2023-03-01 03:00:00',1),(27,37,9,'帮助宣传金桂镇的桂花茶文化活动。','','','2023-04-01 05:00:00','2023-04-01 05:00:00',2),(28,38,10,'协助松柏镇滑雪场推广宣传。','','','2023-05-01 01:30:00','2023-05-01 01:30:00',0),(29,39,1,'愿意支持荷花镇的荷灯展宣传工作。','','','2023-06-01 03:00:00','2023-06-01 03:00:00',1),(30,40,2,'帮助宣传百合镇的花卉博览会活动。','','','2023-07-01 08:00:00','2023-07-01 08:00:00',2),(31,2,1,'我想要助力你',NULL,NULL,'2024-12-26 03:47:17','2024-12-26 03:47:17',1),(32,3,1,'我想要助力你',NULL,NULL,'2024-12-26 05:25:50','2024-12-26 05:25:50',1);
/*!40000 ALTER TABLE `assistance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assistance_success`
--

DROP TABLE IF EXISTS `assistance_success`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assistance_success` (
  `success_id` int NOT NULL AUTO_INCREMENT,
  `publicity_id` int NOT NULL,
  `publicity_user_id` int NOT NULL,
  `assistance_id` int NOT NULL,
  `assistance_user_id` int NOT NULL,
  `accepted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`success_id`),
  KEY `publicity_id` (`publicity_id`),
  KEY `publicity_user_id` (`publicity_user_id`),
  KEY `assistance_id` (`assistance_id`),
  KEY `assistance_user_id` (`assistance_user_id`),
  CONSTRAINT `assistance_success_ibfk_1` FOREIGN KEY (`publicity_id`) REFERENCES `publicity` (`publicity_id`),
  CONSTRAINT `assistance_success_ibfk_2` FOREIGN KEY (`publicity_user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `assistance_success_ibfk_3` FOREIGN KEY (`assistance_id`) REFERENCES `assistance` (`assistance_id`),
  CONSTRAINT `assistance_success_ibfk_4` FOREIGN KEY (`assistance_user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assistance_success`
--

LOCK TABLES `assistance_success` WRITE;
/*!40000 ALTER TABLE `assistance_success` DISABLE KEYS */;
INSERT INTO `assistance_success` VALUES (1,12,4,2,4,'2023-01-20 01:30:00'),(2,15,7,5,7,'2023-05-15 03:00:00'),(3,18,10,8,10,'2023-08-01 08:00:00'),(4,21,3,11,3,'2023-11-01 03:00:00'),(5,24,6,14,6,'2024-02-01 03:00:00'),(6,27,9,17,9,'2024-05-01 07:00:00'),(7,30,2,20,2,'2024-08-01 02:00:00'),(8,33,5,23,5,'2024-11-01 01:00:00'),(9,36,8,26,8,'2023-03-01 03:00:00'),(10,39,1,29,1,'2023-06-01 03:00:00'),(16,2,2,31,1,'2024-12-26 03:48:49'),(17,3,3,32,1,'2024-12-26 05:26:15');
/*!40000 ALTER TABLE `assistance_success` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monthly_summary`
--

DROP TABLE IF EXISTS `monthly_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_summary` (
  `summary_id` int NOT NULL AUTO_INCREMENT,
  `month` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `town_id` int NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_publicity_users` int DEFAULT '0',
  `total_assistance_users` int DEFAULT '0',
  PRIMARY KEY (`summary_id`),
  KEY `town_id` (`town_id`),
  CONSTRAINT `monthly_summary_ibfk_1` FOREIGN KEY (`town_id`) REFERENCES `towns` (`town_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monthly_summary`
--

LOCK TABLES `monthly_summary` WRITE;
/*!40000 ALTER TABLE `monthly_summary` DISABLE KEYS */;
INSERT INTO `monthly_summary` VALUES (1,'202201','江苏省-南京市',20,'古街游览',1,0),(2,'202202','浙江省-杭州市',15,'地方特产',1,0),(3,'202203','四川省-成都市',12,'冬季旅游',1,0),(4,'202204','广东省-深圳市',19,'文化活动',1,0),(5,'202205','贵州省-贵阳市',18,'花卉节',1,0),(6,'202206','湖北省-武汉市',9,'采摘体验',1,0),(7,'202207','湖南省-长沙市',13,'水乡游览',1,0),(8,'202208','四川省-成都市',2,'美食文化',1,0),(9,'202209','北京市-北京市',6,'古迹探访',1,0),(10,'202210','陕西省-西安市',16,'自然生态',1,0),(11,'202211','广东省-广州市',5,'美食打卡',1,0),(12,'202211','江西省-南昌市',11,'自然风光',1,0),(13,'202212','福建省-厦门市',7,'乡村游览',1,0),(14,'202301','四川省-成都市',12,'历史文化',1,1),(15,'202301','陕西省-西安市',4,'生态旅游',1,0),(16,'202302','云南省-丽江市',3,'文化遗产',1,0),(17,'202302','湖南省-长沙市',13,'水上活动',1,0),(18,'202303','广东省-广州市',14,'夜游体验',1,0),(19,'202303','江西省-南昌市',11,'生态休闲',1,0),(20,'202304','浙江省-杭州市',15,'地方特产',1,0),(21,'202305','陕西省-西安市',16,'生态旅游',1,0),(22,'202306','云南省-昆明市',17,'登山活动',1,0),(23,'202307','贵州省-贵阳市',18,'花卉观赏',1,0),(24,'202308','广东省-深圳市',19,'文化活动',1,0),(25,'202309','江苏省-南京市',20,'古镇游览',1,0),(26,'202310','云南省-丽江市',3,'文化推广',1,0),(27,'202311','北京市-北京市',6,'历史遗迹',1,0),(28,'202312','湖北省-武汉市',9,'采摘活动',1,0),(29,'202401','四川省-成都市',12,'自然风光',1,0),(30,'202402','浙江省-杭州市',15,'地方美食',1,0),(31,'202403','浙江省-杭州市',1,'摄影旅游',1,0),(32,'202404','四川省-成都市',2,'民俗体验',1,0),(33,'202405','陕西省-西安市',4,'春游推荐',1,0),(34,'202406','广东省-广州市',5,'美食打卡',1,0),(35,'202407','福建省-厦门市',7,'乡村旅游',1,0),(36,'202408','湖南省-长沙市',8,'艺术文化',1,0),(37,'202409','江苏省-苏州市',10,'灯光秀',1,0),(38,'202410','江西省-南昌市',11,'生态旅游',1,0),(39,'202411','云南省-丽江市',3,'自然风光',1,0),(40,'202411','四川省-成都市',2,'古建筑',1,0),(41,'202411','广东省-广州市',5,'自然风光',1,0),(42,'202411','广东省-广州市',14,'文化节',1,0),(43,'202411','浙江省-杭州市',1,'自然风光',1,0),(44,'202411','陕西省-西安市',4,'古建筑',1,0),(45,'202412','云南省-昆明市',17,'登山游',1,0),(46,'202412','北京市-北京市',6,'古建筑',1,0),(47,'202412','江苏省-苏州市',10,'古建筑',1,0),(48,'202412','湖北省-武汉市',9,'自然风光',1,0),(49,'202412','湖南省-长沙市',8,'古建筑',1,0),(50,'202412','福建省-厦门市',7,'自然风光',1,0),(64,'202303','江苏省-南京市',20,'古街游览',0,1),(65,'202305','浙江省-杭州市',15,'地方特产',0,1),(66,'202306','广东省-深圳市',19,'文化活动',0,1),(67,'202308','贵州省-贵阳市',18,'花卉观赏',0,1),(68,'202311','云南省-丽江市',3,'文化推广',0,1),(69,'202402','四川省-成都市',12,'自然风光',0,1),(70,'202405','四川省-成都市',2,'民俗体验',0,1),(71,'202408','福建省-厦门市',7,'乡村旅游',0,1),(72,'202411','江西省-南昌市',11,'生态旅游',0,1),(73,'202412','云南省-丽江市',3,'自然风光',0,1),(74,'202412','四川省-成都市',2,'古建筑',0,1);
/*!40000 ALTER TABLE `monthly_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publicity`
--

DROP TABLE IF EXISTS `publicity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publicity` (
  `publicity_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `town_id` int NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(2550) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(2550) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`publicity_id`),
  KEY `user_id` (`user_id`),
  KEY `town_id` (`town_id`),
  CONSTRAINT `publicity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `publicity_ibfk_2` FOREIGN KEY (`town_id`) REFERENCES `towns` (`town_id`),
  CONSTRAINT `publicity_chk_1` CHECK ((`status` in (0,-(1))))
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publicity`
--

LOCK TABLES `publicity` WRITE;
/*!40000 ALTER TABLE `publicity` DISABLE KEYS */;
INSERT INTO `publicity` VALUES (1,1,1,'自然风光','西湖美景','西湖的美景令人陶醉，四季皆有不同风貌。','https://img0.baidu.com/it/u=1731782399,129537722&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=1067','http://localhost:8088/uploads/游西湖的最佳路线.mp4','2024-11-05 02:00:00','2024-12-26 03:22:16',0),(2,2,2,'古建筑','武侯祠','武侯祠是纪念三国时期蜀汉丞相诸葛亮的祠堂，具有丰富的历史文化价值。','https://img0.baidu.com/it/u=42206175,880013570&fm=253&fmt=auto&app=120&f=JPEG?w=1424&h=800','http://localhost:8088/uploads/带你看武侯祠的另一面.mp4','2024-11-10 06:00:00','2024-12-26 03:24:44',0),(3,3,3,'自然风光','玉龙雪山','玉龙雪山是丽江的标志性景点，以其壮丽的雪峰和丰富的生态系统闻名。','https://img2.baidu.com/it/u=1910478815,3613315446&fm=253&fmt=auto&app=120&f=JPEG?w=745&h=500','http://localhost:8088/uploads/玉龙雪山.mp4','2024-11-15 01:30:00','2024-12-26 03:24:44',0),(4,4,4,'古建筑','兵马俑','兵马俑是秦始皇陵的重要组成部分，展示了古代军事的辉煌。','https://pic.rmb.bdstatic.com/bjh/news/a3e51c5f8dd3cc13e2bcfb730e3a19d7.jpeg','http://localhost:8088/uploads/兵马俑.mp4','2024-11-20 03:00:00','2024-12-26 03:24:44',0),(5,5,5,'自然风光','珠江夜景','珠江夜景璀璨迷人，是广州夜生活的重要组成部分。','https://img1.baidu.com/it/u=745655978,4204148579&fm=253&fmt=auto&app=120&f=JPEG?w=1200&h=800','http://localhost:8088/uploads/来广州不能错过的珠江夜景.mp4','2024-11-25 10:00:00','2024-12-26 03:24:44',0),(6,6,6,'古建筑','故宫博物院','故宫是明清两代的皇家宫殿，现为博物院，收藏丰富的文物。','https://img0.baidu.com/it/u=4133301291,1877246670&fm=253&fmt=auto&app=120&f=JPEG?w=1201&h=800','http://localhost:8088/uploads/北京故宫博物院.mp4','2024-12-01 01:00:00','2024-12-26 03:24:44',0),(7,7,7,'自然风光','鼓浪屿','鼓浪屿以其独特的建筑风格和美丽的海景吸引了众多游客。','https://img2.baidu.com/it/u=1278910848,4109271193&fm=253&fmt=auto&app=138&f=JPEG?w=1216&h=684','http://localhost:8088/uploads/鼓浪屿.mp4','2024-12-05 07:00:00','2024-12-26 03:24:44',0),(8,8,8,'古建筑','岳麓书院','岳麓书院是中国历史悠久的学府之一，拥有深厚的文化底蕴。','https://img2.baidu.com/it/u=502284461,3689557724&fm=253&fmt=auto&app=120&f=JPEG?w=760&h=1140','http://localhost:8088/uploads/岳麓书院.mp4','2024-12-10 05:00:00','2024-12-26 03:24:44',0),(9,9,9,'自然风光','东湖风景区','东湖是武汉最大的城市湖泊，景色优美，适合休闲娱乐。','https://bj.bcebos.com/bjh-pixel/1700780319774812900_3_ainote_new.jpg','http://localhost:8088/uploads/东湖风景区.mp4','2024-12-15 08:30:00','2024-12-26 03:24:44',0),(10,10,10,'古建筑','拙政园','拙政园是中国四大名园之一，以其精致的园林设计闻名。','https://img0.baidu.com/it/u=2188032961,342791562&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=1200','http://localhost:8088/uploads/鼓浪屿.mp4','2024-12-20 02:30:00','2024-12-26 03:24:44',0),(11,1,11,'自然风光','春柳镇的柳树成荫','春柳镇的风景宜人，特别适合春季游览。','','','2022-11-20 01:00:00','2022-11-20 01:00:00',0),(12,2,12,'历史文化','松柏镇的红色旅游','松柏镇拥有丰富的红色文化资源。','','','2023-01-05 02:00:00','2023-01-05 02:00:00',0),(13,3,13,'水上活动','碧水镇的划船之旅','碧水镇以其优美的湖泊和划船活动闻名。','','','2023-02-18 03:30:00','2023-02-18 03:30:00',0),(14,4,14,'夜游体验','星月镇的夜市活动','星月镇的夜市活动结合了购物和美食体验。','','','2023-03-12 10:30:00','2023-03-12 10:30:00',0),(15,5,15,'地方特产','金桂镇的桂花美食','金桂镇以桂花为特色，开发了多种美食产品。','','','2023-04-22 06:00:00','2023-04-22 06:00:00',0),(16,6,16,'生态旅游','银杏镇的自然生态','银杏镇的自然生态保护区是游客的必访之地。','','','2023-05-18 05:00:00','2023-05-18 05:00:00',0),(17,7,17,'登山活动','红枫镇的登山健身','红枫镇的登山步道每年吸引大量的健身爱好者。','','','2023-06-15 01:00:00','2023-06-15 01:00:00',0),(18,8,18,'花卉观赏','百合镇的百合花海','百合镇的百合花海成为网红拍照打卡点。','','','2023-07-10 08:00:00','2023-07-10 08:00:00',0),(19,9,19,'文化活动','荷花镇的荷花节','荷花镇的荷花节是夏季最受欢迎的文化活动之一。','','','2023-08-15 06:00:00','2023-08-15 06:00:00',0),(20,10,20,'古镇游览','绿柳镇的古街文化','绿柳镇的古街文化展示了江南风情的独特魅力。','','','2023-09-05 02:30:00','2023-09-05 02:30:00',0),(21,1,3,'文化推广','绿水镇的民俗文化展示','绿水镇的文化活动展示了丰富的民俗风情。','','','2023-10-20 03:00:00','2023-10-20 03:00:00',0),(22,2,6,'历史遗迹','金川镇的文化传承','金川镇的历史遗迹吸引了众多文化爱好者。','','','2023-11-18 07:30:00','2023-11-18 07:30:00',0),(23,3,9,'采摘活动','天河镇的家庭采摘游','天河镇的采摘活动为家庭出游提供了绝佳选择。','','','2023-12-10 02:00:00','2023-12-10 02:00:00',0),(24,4,12,'自然风光','松柏镇的冬季雪景','松柏镇的冬季雪景宛如童话世界。','','','2024-01-15 03:30:00','2024-01-15 03:30:00',0),(25,5,15,'地方美食','金桂镇的桂花糕','金桂镇的桂花糕是当地著名的特产之一。','','','2024-02-20 01:30:00','2024-02-20 01:30:00',0),(26,6,1,'摄影旅游','阳光镇的摄影胜地','阳光镇是摄影爱好者的天堂，风景如画。','','','2024-03-15 02:30:00','2024-03-15 02:30:00',0),(27,7,2,'民俗体验','红山镇的火锅文化','红山镇不仅有川味火锅，还有独特的火锅文化体验。','','','2024-04-20 07:00:00','2024-04-20 07:00:00',0),(28,8,4,'春游推荐','青山镇的花卉展览','每年春天，青山镇举办盛大的花卉展览。','','','2024-05-10 01:30:00','2024-05-10 01:30:00',0),(29,9,5,'美食打卡','紫花镇的夜市文化','紫花镇的夜市不仅有美食，还有丰富的夜间活动。','','','2024-06-18 11:00:00','2024-06-18 11:00:00',0),(30,10,7,'乡村旅游','银泉镇的生态农场','银泉镇生态农场适合家庭游客，是亲子游的好选择。','','','2024-07-22 02:00:00','2024-07-22 02:00:00',0),(31,1,8,'艺术文化','白云镇的传统舞蹈','白云镇的传统舞蹈展示了独特的地方文化风情。','','','2024-08-15 06:30:00','2024-08-15 06:30:00',0),(32,2,10,'灯光秀','东风镇的夏季活动','东风镇的夏季灯光秀吸引了成千上万的游客。','','','2024-09-05 12:00:00','2024-09-05 12:00:00',0),(33,3,11,'生态旅游','春柳镇的绿道骑行','春柳镇开辟了绿道骑行路线，是骑行爱好者的首选。','','','2024-10-10 01:00:00','2024-10-10 01:00:00',0),(34,4,14,'文化节','星月镇的星空音乐节','星月镇每年举办的星空音乐节成为年轻人热门活动。','','','2024-11-15 10:30:00','2024-11-15 10:30:00',0),(35,5,17,'登山游','红枫镇的健身之旅','红枫镇的健身步道吸引了众多户外运动爱好者。','','','2024-12-10 02:30:00','2024-12-10 02:30:00',0),(36,6,20,'古街游览','绿柳镇的古街夜景','绿柳镇的古街夜景灯火辉煌，是游客必去之地。','','','2022-01-12 11:00:00','2022-01-12 11:00:00',0),(37,7,15,'地方特产','金桂镇的桂花茶','金桂镇的桂花茶是游客喜爱的伴手礼之一。','','','2022-02-28 03:00:00','2022-02-28 03:00:00',0),(38,8,12,'冬季旅游','松柏镇的滑雪场','松柏镇的滑雪场提供了丰富的冬季户外体验。','','','2022-03-20 01:30:00','2022-03-20 01:30:00',0),(39,9,19,'文化活动','荷花镇的荷灯展','荷花镇每年举办的荷灯展是文化艺术的象征。','','','2022-04-15 12:00:00','2022-04-15 12:00:00',0),(40,10,18,'花卉节','百合镇的花卉博览会','百合镇的花卉博览会吸引了大量园艺爱好者。','','','2022-05-25 07:00:00','2022-05-25 07:00:00',0),(41,1,9,'采摘体验','天河镇的橙子采摘季','天河镇每年冬季的橙子采摘活动深受欢迎。','','','2022-06-10 02:00:00','2022-06-10 02:00:00',0),(42,2,13,'水乡游览','碧水镇的渔家风情','碧水镇的渔村生活展示了独特的水乡文化。','','','2022-07-18 06:30:00','2022-07-18 06:30:00',0),(43,3,2,'美食文化','红山镇的川菜体验','红山镇的川菜文化吸引了大批美食爱好者。','','','2022-08-22 04:00:00','2022-08-22 04:00:00',0),(44,4,6,'古迹探访','金川镇的古塔文化','金川镇的古塔是当地标志性的文化遗产。','','','2022-09-30 03:00:00','2022-09-30 03:00:00',0),(45,5,16,'自然生态','银杏镇的生态保护区','银杏镇的自然保护区展示了丰富的生物多样性。','','','2022-10-25 06:00:00','2022-10-25 06:00:00',0),(46,6,5,'美食打卡','紫花镇的特色小吃','紫花镇以其丰富的小吃文化闻名全国。','','','2022-11-18 04:30:00','2022-11-18 04:30:00',0),(47,7,7,'乡村游览','银泉镇的农家乐体验','银泉镇的农家乐让游客感受到真正的田园生活。','','','2022-12-05 08:00:00','2022-12-05 08:00:00',0),(48,8,4,'生态旅游','青山镇的绿道徒步','青山镇的徒步绿道适合家庭和团体游客。','','','2023-01-10 02:30:00','2023-01-10 02:30:00',0),(49,9,3,'文化遗产','绿水镇的非遗表演','绿水镇的非遗表演展示了丰富的地方传统文化。','','','2023-02-15 07:00:00','2023-02-15 07:00:00',0),(50,10,11,'生态休闲','春柳镇的湖边垂钓','春柳镇的湖泊垂钓区吸引了大批休闲游客。','','','2023-03-20 06:00:00','2023-03-20 06:00:00',0);
/*!40000 ALTER TABLE `publicity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `towns`
--

DROP TABLE IF EXISTS `towns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `towns` (
  `town_id` int NOT NULL AUTO_INCREMENT,
  `town_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`town_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `towns`
--

LOCK TABLES `towns` WRITE;
/*!40000 ALTER TABLE `towns` DISABLE KEYS */;
INSERT INTO `towns` VALUES (1,'西湖','杭州市','浙江省'),(2,'武侯祠','成都市','四川省'),(3,'玉龙雪山','丽江市','云南省'),(4,'兵马俑','西安市','陕西省'),(5,'珠江夜景','广州市','广东省'),(6,'故宫博物院','北京市','北京市'),(7,'鼓浪屿','厦门市','福建省'),(8,'岳麓书院','长沙市','湖南省'),(9,'东湖风景区','武汉市','湖北省'),(10,'拙政园','苏州市','江苏省'),(11,'阳光镇','南昌市','江西省'),(12,'红山镇','成都市','四川省'),(13,'绿水镇','长沙市','湖南省'),(14,'青山镇','广州市','广东省'),(15,'紫花镇','杭州市','浙江省'),(16,'金川镇','西安市','陕西省'),(17,'银泉镇','昆明市','云南省'),(18,'白云镇','贵阳市','贵州省'),(19,'天河镇','深圳市','广东省'),(20,'东风镇','南京市','江苏省'),(21,'春柳镇','大连市','辽宁省'),(22,'松柏镇','哈尔滨市','黑龙江省'),(23,'碧水镇','武汉市','湖北省'),(24,'星月镇','泉州市','福建省'),(25,'金桂镇','桂林市','广西壮族自治区'),(26,'银杏镇','合肥市','安徽省'),(27,'红枫镇','宜昌市','湖北省'),(28,'百合镇','拉萨市','西藏自治区'),(29,'荷花镇','嘉兴市','浙江省'),(30,'绿柳镇','苏州市','江苏省'),(31,'美丽草原','呼和浩特市','内蒙古自治区'),(32,'美丽的大草原','呼和浩特市','内蒙古自治区');
/*!40000 ALTER TABLE `towns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` tinyint NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatar_url` varchar(2550) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `users_chk_1` CHECK ((`user_type` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'cok','20030116Zy',1,'zhangziliang','ID_CARD','511902200301160016','13608249555','我是cok，大家好~','2024-12-19 13:20:32','2024-12-26 03:54:16',''),(2,'user01','P@ssw0rd123',0,'李明','ID_CARD','123456789012345678','13800000001','热爱编程和技术，喜欢解决各种挑战性问题。','2024-12-22 07:58:47','2024-12-25 16:25:56',''),(3,'user02','W@ngLi2024',0,'王丽','ID_CARD','234567890123456789','13800000002','专注于数据科学与机器学习领域，喜欢阅读科技类书籍。','2024-12-22 08:01:42','2024-12-22 08:33:56',NULL),(4,'user03','Ch3nF@ng!21',0,'陈芳','ID_CARD','456789012345678901','13800000003','在人工智能领域从事研究，热衷于开源技术。','2024-12-22 08:03:03','2024-12-22 08:35:40',NULL),(5,'user04','L!uQiang123',0,'刘强','ID_CARD','567890123456789012','13800000004',' 数据库管理员，关注大数据与云计算的最新发展。','2024-12-22 08:03:48','2024-12-22 08:38:20',NULL),(6,'user05','Yh!2024!',0,'杨华','ID_CARD','678901234567890123','13800000005','前端开发工程师，热衷于用户体验设计和优化。','2024-12-22 08:04:38','2024-12-22 08:39:45',NULL),(7,'user06','Z@oLei#789',0,'赵磊','ID_CARD','789012345678901234','13800000006','软件开发人员，喜欢探索新技术，尤其是在人工智能方面。','2024-12-22 08:05:38','2024-12-22 08:40:56',NULL),(8,'user07','S!nTing321',0,'孙婷','ID_CARD','890123456789012345','13800000007','产品经理，致力于提升用户体验和项目管理。','2024-12-22 08:06:32','2024-12-22 08:42:19',NULL),(9,'user08','H3!Yong2024',0,'何勇','ID_CARD','901234567890123456','13800000008','网络安全专家，关注数据隐私和信息保护领域。','2024-12-22 08:07:22','2024-12-22 08:45:36',NULL),(10,'user09','WN@2024Secure',0,'吴娜','ID_CARD','012345678901234567','13800000009','项目经理，善于跨部门沟通与协调，致力于技术创新。','2024-12-22 08:08:05','2024-12-22 08:46:47',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-01 21:13:07
